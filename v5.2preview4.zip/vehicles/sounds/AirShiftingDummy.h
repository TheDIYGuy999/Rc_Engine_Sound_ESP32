const unsigned int shiftingSampleRate = 22050;
const unsigned int shiftingSampleCount = 2;
const signed char shiftingSamples[] = {
0, 0, };
