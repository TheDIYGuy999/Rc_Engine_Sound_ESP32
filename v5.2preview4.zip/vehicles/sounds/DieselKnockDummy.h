const unsigned int knockSampleRate = 22050;
const unsigned int knockSampleCount = 2;
const signed char knockSamples[] = {
0, 0, };
