const unsigned int parkingBrakeSampleRate = 22050;
const unsigned int parkingBrakeSampleCount = 2;
const signed char parkingBrakeSamples[] = {
0, 0, };
