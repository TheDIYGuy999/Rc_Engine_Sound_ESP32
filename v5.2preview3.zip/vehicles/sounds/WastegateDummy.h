const unsigned int wastegateSampleRate = 22050;
const unsigned int wastegateSampleCount = 2;
const signed char wastegateSamples[] = {
0, 0, };
