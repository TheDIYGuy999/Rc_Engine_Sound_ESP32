const unsigned int brakeSampleRate = 22050;
const unsigned int brakeSampleCount = 2;
const signed char brakeSamples[] = {
0, 0, };
