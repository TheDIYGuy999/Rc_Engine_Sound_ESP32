const unsigned int sirenSampleRate = 22050;
const unsigned int sirenSampleCount = 2;
const signed char sirenSamples[] = {
0, 0, };
