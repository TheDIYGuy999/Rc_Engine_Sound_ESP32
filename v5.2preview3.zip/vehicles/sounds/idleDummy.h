const unsigned int sampleRate = 22050;
const unsigned int sampleCount = 3;
const signed char samples[] = {
0, 0, 100, };
