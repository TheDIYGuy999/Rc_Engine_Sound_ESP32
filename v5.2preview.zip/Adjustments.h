/* ******* RECOMMENDED Audacity Settings: 22'050 Hz, 8 bit PCM **********

// Sound files converted with: https://bitluni.net/wp-content/uploads/2018/01/Audio2Header.html
// converter code by bitluni (send him a high five, if you like the code)

Recommended ESC & settings for TAMIYA trucks with 3 speed transmission:

ESC: HOBBYWING QUICRUN WP Crawler Brushed with the following settings:
1: 3
2: 1
3: 3
4: 3
5: 4
6: 2
7: 9
8: 1 
9: 8 (change it, important)
10: 4
11: 4
12: 5
13: 4
14: 1 (be careful here!!)
15: 1 (change it, important)

Motor: 540 size, 35 turns, stock pinion
*/

// BOARD SETTINGS ******************************************************************************************************
// Choose the board version
//#define PROTOTYPE_36 // 36 or 30 pin board (do not uncomment it or it will cause boot issues!)

// COMMUNICATION SETTINGS **********************************************************************************************
// Choose the receiver communication mode (never uncomment more than one! If all commented out = classic PWM RC signal communication)
// NOTE: SBUS is strongly recommended, because it allows to have a bigger RPM range: TOP_SPEED_MULTIPLIER can be 4 instead of 3

// SBUS communication --------
#define SBUS_COMMUNICATION // control signals are coming in via the SBUS interface (comment it out for classic PWM RC signals)
boolean sbusInverted = true; // true = wired to non standard (inverted) SBUS signal (for example from "Micro RC" receiver)

// IBUS communication (TODO Experimental, untested!)--------
//#define IBUS_COMMUNICATION // control signals are coming in via the IBUS interface (comment it out for classic PWM RC signals)

// Serial communication (deprecated, use SBUS) --------
//#define SERIAL_COMMUNICATION // control signals are coming in via the serial interface (comment it out for classic PWM RC signals)
// Only for my "Micro RC" receiver! See: https://github.com/TheDIYGuy999/Micro_RC_Receiver

// PPM communication --------
//#define PPM_COMMUNICATION // control signals are coming in via the PPM interface (comment it out for classic PWM RC signals)
#define NUM_OF_CHL 8          // The number of channels inside our PPM signal (usually max. 8)
#define NUM_OF_AVG 1          // Number of averaging passes (usually one, more will be slow)

// VEHICLE SETTINGS ****************************************************************************************************
// Select the vehicle you want (uncomment the one you want)

// Master --------
//#include "config/00_Master.h" // This master configuration contains all available sound files (base for new vehicles)

// US trucks --------
//#include "config/CaboverCAT3408.h" // Cabover truck with Caterpillar 3408 V8 Diesel
//#include "config/KenworthW900ADetroit8V71.h" // Kenworth W900A with Detroit 8V71 V8 2 stroke Diesel
#include "config/KenworthW900ACAT3408.h" // Kenworth W900A with Caterpillar 3408 V8 Diesel
//#include "config/KenworthCummins335.h" // 1950ies Kenworth with Cummins 335 R6 Diesel
//#include "config/MackSuperLiner.h" // MACK Super Liner (TODO, needs rework)

// EU trucks --------
//#include "config/Tatra813.h" // Tatra 813 8x8 V12 Diesel military truck (old version for comparison, don't use it)
//#include "config/Tatra813new.h" // Tatra 813 8x8 V12 Diesel military truck
//#include "config/UmimogU1000.h" // Umimog U 1000 with turbocharged R6 Diesel incl. Feuerwehr Martinshorn (TODO, rework idle)

// Russian trucks --------
//#include "config/Ural4320.h" // URAL 4320 6x6 V8 Diesel military truck

// US motorcycles --------
//#include "config/HarleyDavidsonFXSB.h" // Harley Davidson FXSB V2 Motorcycle

// US cars --------

// EU cars --------

// US SUV --------
//#include "config/JeepGrandCherokeeTrackhawk.h" // Jeep Grand Cherokee Trackhawk V8 monster SUV with supercharger

// EU SUV --------
//#include "config/DefenderV8Automatic.h" // Land Rover Defender 90 V8 Automatic (very nice V8 with lots of bass)
//#include "config/DefenderV8CrawlerAutomatic.h" // Land Rover Defender 90 V8 Automatic
//#include "config/DefenderTd5.h" // Land Rover Defender 90 Td5 R5 Diesel
